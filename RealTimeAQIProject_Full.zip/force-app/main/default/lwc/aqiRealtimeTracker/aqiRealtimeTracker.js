import { LightningElement, track } from 'lwc';
import getAQIByCoordinates from '@salesforce/apex/RealTimeAQIController.getAQIByCoordinates';

export default class AqiRealtimeTracker extends LightningElement {
    @track aqi;
    @track statusLabel = '';

    handleAQICheck() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const { latitude, longitude } = position.coords;
                getAQIByCoordinates({ latitude, longitude })
                    .then(result => {
                        this.aqi = result;
                        this.statusLabel = this.getAQILabel(result);
                    })
                    .catch(error => {
                        console.error('Error fetching AQI:', error);
                    });
            }, err => {
                console.error('Geolocation failed', err);
            });
        }
    }

    getAQILabel(aqi) {
        switch (aqi) {
            case 1: return 'Good';
            case 2: return 'Fair';
            case 3: return 'Moderate';
            case 4: return 'Poor';
            case 5: return 'Very Poor';
            default: return 'Unknown';
        }
    }
}
